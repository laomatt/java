/**
 * Author: Han Yan
 * Date: 04/09/2013
 * Program Name: ColorFactory.java
 * Objective: This program draws the whole frame of the application.    
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ColorFactory extends JFrame
{
    public static final int DECIMAL = 1;
    public static final int BINARY = 2;
    public static final int OCTAL = 3;
    public static final int HEXIDECIMAL = 4;
    
    private int type = DECIMAL;
    
    private JPanel jp1, jp2, jp21, jp3, jp31, jp32, jp6;
    private OvalPanel jp4;
    private HistogramPanel jp5;
    private JRadioButton jrb1, jrb2, jrb3, jrb4;
    private JScrollBar jsb1, jsb2, jsb3;
    
    /*****************************ColorFactory()***************************/
    public ColorFactory() 
    {
        // The title of the program
        JLabel jl = new JLabel("ColorFactory");
        jl.setFont(new Font("Comic Sans MS", Font.BOLD, 24));
        jl.setForeground(Color.MAGENTA);
        jp1 = new JPanel();
        jp1.add(jl);
        
        // The number format panel
        jp21 = new JPanel(new GridLayout(4, 1));
        
        jrb1 = new JRadioButton("Decimal", true);
        jrb2 = new JRadioButton("Binary", false);
        jrb3 = new JRadioButton("Octal", false);
        jrb4 = new JRadioButton("Hexidecimal", false);
        
        // Put the radio buttons in a group so that they cannot be selected at the same time here
        ButtonGroup group = new ButtonGroup();
        group.add(jrb1);
        group.add(jrb2);
        group.add(jrb3);
        group.add(jrb4);
        
        jp21.add(jrb1);
        jp21.add(jrb2);
        jp21.add(jrb3);
        jp21.add(jrb4);
        
        // Add radio buttons to a panel with flow layout
        jp2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 0));
        jp2.add(jp21);
        
        // The color adjusting panel
        jsb1 = new JScrollBar(JScrollBar.HORIZONTAL, 0, 1, 0, 256);
        jsb2 = new JScrollBar(JScrollBar.HORIZONTAL, 0, 1, 0, 256);
        jsb3 = new JScrollBar(JScrollBar.HORIZONTAL, 0, 1, 0, 256);
        
        // Set the size of each scroll bar here
        jsb1.setPreferredSize(new Dimension(200, 15));
        jsb1.setPreferredSize(new Dimension(200, 15));
        jsb1.setPreferredSize(new Dimension(200, 15));
        
        // The internal panel that contains labels
        jp31 = new JPanel(new GridLayout(3, 1, 0, 20));
        jp31.add(new JLabel("Red"));
        jp31.add(new JLabel("Green"));
        jp31.add(new JLabel("Blue"));
        
        // The internal panel that contains scroll bars
        jp32 = new JPanel(new GridLayout(3, 1, 0, 20));
        jp32.add(jsb1);
        jp32.add(jsb2);
        jp32.add(jsb3);
        
        // Add labels and buttons in a panel with flow layout
        jp3 = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 0));
        jp3.add(jp31);
        jp3.add(jp32);
        
        // The panel that draws the oval
        jp4 = new OvalPanel(jsb1.getValue(), jsb2.getValue(), jsb3.getValue());
        // The panel that draws the histogram
        jp5 = new HistogramPanel(type, jsb1.getValue(), jsb2.getValue(), jsb3.getValue());
        
        // Put the body panels in a panel with grid layout
        jp6 = new JPanel(new GridLayout(2, 2, 40, 0));
        jp6.add(jp4);
        jp6.add(jp2);
        jp6.add(jp5);
        jp6.add(jp3);
        
        // Put the title and body in a frame with border layout
        setLayout(new BorderLayout(0, 20));
        
        add(jp1, BorderLayout.NORTH);
        add(jp6, BorderLayout.CENTER);
        
        registerListeners();
    }		
    
    /******************************registerListeners()**********************************/
    /** Function that registers all the listeners */
    private void registerListeners()
    {	
        jrb1.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e) 
            {
                jp5.setType(DECIMAL);
                repaint();
            }		
        });
        
        jrb2.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e) 
            {
                jp5.setType(BINARY);
                repaint();
            }		
        });
        
        jrb3.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e) 
            {
                jp5.setType(OCTAL);
                repaint();
            }		
        });
        
        jrb4.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e) 
            {
                jp5.setType(HEXIDECIMAL);
                repaint();
            }		
        });
        
        jsb1.addAdjustmentListener(new AdjustmentListener()
        {
            public void adjustmentValueChanged(AdjustmentEvent e)
            {
                jp4.setRed(jsb1.getValue());
                jp5.setRed(jsb1.getValue());
                repaint();
            }
        });
        
        jsb2.addAdjustmentListener(new AdjustmentListener()
        {
            public void adjustmentValueChanged(AdjustmentEvent e)
            {
                jp4.setGreen(jsb2.getValue());
                jp5.setGreen(jsb2.getValue());
                repaint();
            }
        });
        	
        jsb3.addAdjustmentListener(new AdjustmentListener()
        {
            public void adjustmentValueChanged(AdjustmentEvent e)
            {
                jp4.setBlue(jsb3.getValue());
                jp5.setBlue(jsb3.getValue());
                repaint();
            }
        });
    }
    
    /******************************paintComponent()********************************/
    /** function that draws part of the frame */
    protected void paintComponent(Graphics g)
    {
        // Only repaint the specified panels, not all of the frame here
        jp4.repaint();
        jp5.repaint();
    }
}



