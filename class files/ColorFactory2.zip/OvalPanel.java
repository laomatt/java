/**
 * Author: Han Yan
 * Date: 04/09/2013
 * Program Name: OvalDanel.java
 * Objective: This program takes the values from the JScrollBar to set
 *            the color of the oval and draws the oval.    
 */


import java.awt.*;
import javax.swing.*;

public class OvalPanel extends JPanel
{
    private int red;
    private int green;
    private int blue;
	
    /************************OvalPanel()************************/
    public OvalPanel(int red, int green, int blue) {
        this.red = red;
        this.green = green;
        this.blue = blue;
    }
    
    /************************setRed()***************************/
    /** Set red value */
    public void setRed(int value)
    {
	    red = value;
    }
	
    /************************setGreen()*************************/
    /** Set green value */
    public void setGreen(int value)
    {
        green = value;
    }
	
    /************************setBlue()************************/
    /** Set blue value */
    public void setBlue(int value)
    {
        blue = value;
    }
	
    /************************paintComponent()************************/
    /** Function that draws the oval here */
    protected void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        
        g.setColor(new Color(red, green, blue));
        int height = getHeight();
        int width = getWidth();
        
        g.fillOval(25, 25, width - 50, height - 50);
    }
}



