/**
 * Author: Han Yan
 * Date: 04/09/2013
 * Program Name: HistogramPanel.java
 * Objective: This program takes the values from the JScrollBar to set
 *            the height of the red, green, and blue bar, use the type
 *            values from the JRadioButton to set the type of the values to
 *            be shown under the bars, and draws the bars and the values.    
 */

import java.awt.*;
import javax.swing.JPanel;

public class HistogramPanel extends JPanel 
{
    private int type;
    private int red;
    private int green;
    private int blue;
    
    /****************************HisTogramPanel()**************************/
    public HistogramPanel(int type, int red, int green, int blue)
    {
        this.type = type;
        this.red = red;
        this.green = green;
        this.blue = blue;
    }
	
    /****************************setType()**************************/
    /** Set the type */
    public void setType(int newType)
    {
        type = newType;
    }
	
    /****************************setRed()**************************/
    /** Set red value */
    public void setRed(int value)
    {
        red = value;
    }
	
    /****************************setGreen()**************************/
    /** Set green value */
    public void setGreen(int value)
    {
        green = value;
    }
	
    /****************************setBlue()**************************/
    /** Set blue value */
    public void setBlue(int value)
    {
        blue = value;
    }
	
    /****************************paintComponent()**************************/
    /** Function that draws the histogram */
    protected void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        
        int height = getHeight();
        int width = getWidth();
        
        int currHeightRed = (int)((height - 40) * 1.0 / 255 * red);
        int currHeightGreen = (int)((height - 40) * 1.0 / 255 * green);
        int currHeightBlue = (int)((height - 40) * 1.0 / 255 * blue);
        int rectWidth = (width - 25 * 2 - 25 * 2 - 30 * 3) / 3;
        
        // Draw the red bar
        g.setColor(Color.RED);
        if (red == 0) 
        {
            g.drawLine(40, height - 50, 40 + rectWidth, height - 50);
        }
        else 
        {
            g.fillRect(40, height - 50 - currHeightRed, rectWidth, currHeightRed);
        }
        
        // Draw the green bar
        g.setColor(Color.GREEN);
        if (green == 0)
        {
            g.drawLine(40 + 25 + rectWidth + 30, height - 50, 40 + 25 + rectWidth * 2 + 30, height - 50);
        }
        else
        {
            g.fillRect(40 + 25 + rectWidth + 30, height - 50 - currHeightGreen, rectWidth, currHeightGreen);
        }
        
        // Draw the blue bar
        g.setColor(Color.BLUE);
        if (blue == 0)
        {
            g.drawLine(40 + 25 * 2 + rectWidth * 2 + 30 * 2, height - 50, 40 + 25 * 2 + rectWidth * 3 + 30 * 2, height - 50);
        }
        else {
            g.fillRect(40 + 25 * 2 + rectWidth * 2 + 30 * 2, height - 50 - currHeightBlue, rectWidth, currHeightBlue);
        }
        
        String numRed = null;
        String numGreen = null;
        String numBlue = null;
        
        // Set the numbers shown to the correct type
        switch (type)
        {
            case 1:
                numRed = Integer.toString(red);
                numGreen = Integer.toString(green);
                numBlue = Integer.toString(blue);
                break;
            case 2:
                numRed = Integer.toBinaryString(red);
                numGreen = Integer.toBinaryString(green);
                numBlue = Integer.toBinaryString(blue);
                break;
            case 3:
                numRed = Integer.toOctalString(red);
                numGreen = Integer.toOctalString(green);
                numBlue = Integer.toOctalString(blue);
                break;
            case 4:
                numRed = Integer.toHexString(red);
                numGreen = Integer.toHexString(green);
                numBlue = Integer.toHexString(blue);
                break;
        }
        
        // Display the number here
        g.setFont(new Font("Arial", Font.BOLD, 16));
        g.setColor(Color.BLACK);
        g.drawString(numRed, 40, height - 25);
        g.drawString(numGreen, 40 + 25 + rectWidth + 30, height - 25);
        g.drawString(numBlue, 40 + 25 * 2 + rectWidth * 2 + 30 * 2, height - 25);
    }
}



