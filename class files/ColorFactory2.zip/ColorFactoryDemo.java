/**
 * Author: Han Yan
 * Date: 04/09/2013
 * Program Name: ColorFactoryDemo.java
 * Objective: This program is entrance of the whole application.       
 */

import javax.swing.*;

public class ColorFactoryDemo {
	
    /************************* Main()**************************/
    public static void main(String[] args)
    {
        ColorFactory cf = new ColorFactory();
        cf.setTitle("ColorFactoryDemo");
        cf.setSize(650, 450);
        // Center the frame
        cf.setLocationRelativeTo(null);
        cf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        cf.setVisible(true);
    }
}



